<?php

namespace App\Http\Controllers;

use App\Http\Resources\TicketSolutionResource;
use App\Models\TicketHistory;
use App\Models\TicketSolution;
use App\Models\User;
use App\Notifications\BasicNotification;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class TicketSolutionController extends Controller
{

    public function index()
    {
        //
    }


    public function create()
    {
        //
    }


    public function store(Request $request)
    {
        // Validación personalizada para evitar imágenes en base64
        if (preg_match('/data:image\/[^;]+;base64/', $request->description)) {
            throw ValidationException::withMessages([
                'description' => 'No se permite pegar imágenes directamente en el texto. Por favor, usa el botón de "Adjuntar archivos" para subir tus imágenes.'
            ]);
        }

        $ticket_solution = TicketSolution::create([
            'description' => $request->description,
            'ticket_id' => $request->ticketId,
            'user_id' => auth()->id(),
        ]);

        // marcar como completado el ticket
        // $ticket_solution->ticket->update(['status' => 'Completado']); //quisieron quitar esta funcion el 02/Abr/2024 por Rmses

        // Guardar media
        $ticket_solution->addAllMediaFromRequest()->each(fn($file) => $file->toMediaCollection());

        //Crear registro de actividad
        TicketHistory::create([
            'description' =>  'publicó una solución',
            'user_id' =>  auth()->id(),
            'ticket_id' =>  $request->ticketId,
        ]);

        // notificar a creador de ticket
        // $users = User::find($ticket_solution->ticket->user_id);
        // $owner = auth()->user();
        // $description = "agregó una solución al ticket #{$ticket_solution->ticket->id}";
        // $subject = "Ticket cerrado";
        // $users->each(fn ($user) => $user->notify(new BasicNotification($subject, $description, $owner->name, $owner->profile_photo_url, route('tickets.show', $ticket_solution->ticket->id))));

        return response()->json(['item' => $ticket_solution]);
    }


    public function show(TicketSolution $ticket_solution)
    {
        //
    }


    public function edit(TicketSolution $ticketSolution)
    {
        //
    }


    public function update(Request $request, TicketSolution $ticket_solution)
    {
        //
    }


    public function destroy(TicketSolution $ticket_solution)
    {
        //Crear registro de actividad
        TicketHistory::create([
            'description' =>  "eliminó la solución registrada el {$ticket_solution->created_at->toDateTimeString()} de este ticket",
            'user_id' =>  auth()->id(),
            'ticket_id' =>  $ticket_solution->ticket->id,
        ]);

        $ticket_solution->delete();
    }


    public function fetchSolutions($ticket)
    {
        $ticket_solutions = TicketSolutionResource::collection(TicketSolution::with('user:id,name,profile_photo_path')
            ->where('ticket_id', $ticket)
            ->oldest('created_at')
            ->get());

        return response()->json(['items' => $ticket_solutions]);
    }
}